package com.odev;

public class Test {
	public static void Function(String arg) {
		System.out.println("Test fonksiyonu �al��t�r�ld�. (" + arg + ")");
	}
}
