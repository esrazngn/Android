package com.odev;

public class Siparisim {
	String key;
	double value;

	public void yemekEkle(String key, Double value) {
		this.key = key;
		this.value = value;
	}

	public void icecekEkle(String key, Double value) {
		this.key = key;
		this.value = value;
	}

	public void salataEkle(String key, Double value) {
		this.key = key;
		this.value = value;
	}

}
