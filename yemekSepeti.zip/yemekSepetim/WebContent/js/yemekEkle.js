function yemekEkle() {	
		
		//var index =parseInt(document.getElementById(yemekler).value);
		alert(5);
		//<%-- <% int index = Integer.valueOf((session).getAttribute("yemekler").toString());%> 
		//Comment
		//yeme�in indexini g�nderebiliyorum faakt bu indexi jsp de kullanam�yorum.
		//jsp de�i�kenini js at�yabiliyorum fakat js de�i�kenini jsp atayam�yorum. --%>
		//var adeti = parseInt(document.siparis.yemekAdet.value);
	   // document.getElementById(area).value = document.getElementById(area).value + value.replace('&nbsp', ' ').replace('&nbsp', ' ').replace('&nbsp', ' ').replace('&nbsp', ' ')+" " + adeti+" adet "+"\n";
	}